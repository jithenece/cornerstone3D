/** used for CPU rendering */
type TransformMatrix2D = [number, number, number, number, number, number];

export default TransformMatrix2D;
