/**
 * This represents a 4-vector or RGBA value.
 */
type Point4 = [number, number, number, number];

export default Point4;
