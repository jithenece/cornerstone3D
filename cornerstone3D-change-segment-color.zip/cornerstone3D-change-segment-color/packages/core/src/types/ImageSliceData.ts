type ImageSliceData = {
  numberOfSlices: number;
  imageIndex: number;
};

export default ImageSliceData;
