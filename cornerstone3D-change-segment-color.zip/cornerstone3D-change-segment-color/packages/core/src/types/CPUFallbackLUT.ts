type CPUFallbackLUT = {
  lut: number[];
};

export default CPUFallbackLUT;
