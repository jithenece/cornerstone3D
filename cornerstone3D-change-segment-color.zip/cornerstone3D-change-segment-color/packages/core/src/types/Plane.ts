/**
 * Plane equation Ax+By+Cz=D, plane is defined by [A, B, C, D]
 */
type Plane = [number, number, number, number];

export default Plane;
