/**
 * RGB color type.
 */
type RGB = [number, number, number];

export default RGB;
