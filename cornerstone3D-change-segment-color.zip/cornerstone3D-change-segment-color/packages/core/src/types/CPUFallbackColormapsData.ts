import CPUFallbackColormapData from './CPUFallbackColormapData';

type CPUFallbackColormapsData = {
  [key: string]: CPUFallbackColormapData;
};

export default CPUFallbackColormapsData;
