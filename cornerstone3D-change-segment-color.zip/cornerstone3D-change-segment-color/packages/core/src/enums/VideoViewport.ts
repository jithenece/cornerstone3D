/**
 * video viewport speed units
 */
enum SpeedUnit {
  FRAME = 'f',
  SECOND = 's',
}

export { SpeedUnit };
