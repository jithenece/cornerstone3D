enum OrientationAxis {
  AXIAL = 'axial',
  CORONAL = 'coronal',
  SAGITTAL = 'sagittal',
  ACQUISITION = 'acquisition',
}

export default OrientationAxis;
