enum GeometryType {
  CONTOUR = 'contour',
  SURFACE = 'Surface',
}

export default GeometryType;
