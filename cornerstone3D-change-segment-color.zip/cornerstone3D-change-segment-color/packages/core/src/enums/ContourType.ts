enum ContourType {
  CLOSED_PLANAR = 'CLOSED_PLANAR',
  OPEN_PLANAR = 'OPEN_PLANAR',
}

export default ContourType;
