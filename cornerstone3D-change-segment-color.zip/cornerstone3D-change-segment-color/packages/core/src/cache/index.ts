import cache, { Cache } from './cache';
import ImageVolume from './classes/ImageVolume';

export { ImageVolume, Cache };
export default cache;
