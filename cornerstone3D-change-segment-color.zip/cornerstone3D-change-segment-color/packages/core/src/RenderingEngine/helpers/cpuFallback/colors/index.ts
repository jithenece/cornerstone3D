import { getColormap, getColormapsList } from './colormap';
import LookupTable from './lookupTable';

export { getColormap, getColormapsList, LookupTable };
