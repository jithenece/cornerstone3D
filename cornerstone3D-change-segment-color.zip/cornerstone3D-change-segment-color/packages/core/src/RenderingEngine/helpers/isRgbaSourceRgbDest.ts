export default (src, dest) => src.length * 3 === dest.byteLength * 4;
