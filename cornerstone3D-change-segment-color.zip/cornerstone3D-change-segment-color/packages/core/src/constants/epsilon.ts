const EPSILON = 1e-3;

export default EPSILON;
