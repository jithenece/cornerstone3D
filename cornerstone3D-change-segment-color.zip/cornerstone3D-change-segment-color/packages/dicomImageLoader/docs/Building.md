Build System
============

This project uses Webpack to build the software.

Pre-requisites:
---------------

NodeJs - [click to visit web site for installation instructions](http://nodejs.org).

Common Tasks
------------

Update dependencies (after each pull):
> npm install

Running the build:
> npm run build

Automatically running the build and unit tests after each source change:
> npm run watch