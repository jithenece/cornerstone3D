export default "cornerstoneTools@^4.0.0";
