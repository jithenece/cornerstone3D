export default "Cornerstone3DTools@^0.1.0";
