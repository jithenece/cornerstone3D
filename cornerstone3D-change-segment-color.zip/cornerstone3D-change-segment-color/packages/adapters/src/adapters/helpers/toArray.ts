const toArray = x => (Array.isArray(x) ? x : [x]);

export { toArray };
