import Segmentation from "./Segmentation";

const VTKjsSEG = {
    Segmentation
};

export { VTKjsSEG };
